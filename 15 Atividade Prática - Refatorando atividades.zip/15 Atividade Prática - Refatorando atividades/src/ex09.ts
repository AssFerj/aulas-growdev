// Reescreva o exercício 3, utilizando apenas o SWITCH.

let tabela: number = Number(prompt('Digite o valor do produto:'));
let parcela: number = Number(prompt('Digite a quantidade de parcelas:'));
let txAvista: number = preco * 2.5 / 100;
let jrs6a10: number = preco * 6 / 100;
let jrs11a15: number = preco * 13 / 100;
let vrTotal: number = 0;

switch(parcelamento <= 0 || parcelamento >= 16){
    case :
        document.write('Digitar um valor válido para calcular o parcelamento!');
        break;
    case parcelamento >= 16:
        document.write('Digitar um valor válido para calcular o parcelamento!');
        break;
    
}