// Imprima na tela 30 ( trinta ) números ímpares.

let numero: number = 0
       for(let i: number = 0; i<=60; i++){
        if(i%2 != 0){
            console.log(i)
            }
       }