// Utilizando do...while, imprima na tela a soma de 
// todos os números entre 10 e 100.

let soma = 0
let numeroAtual = 11

do{
    soma+=numeroAtual;
    numeroAtual++
}while(numeroAtual < 101)
console.log(soma)
