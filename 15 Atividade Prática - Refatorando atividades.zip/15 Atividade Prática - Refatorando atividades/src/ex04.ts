// Escrever um algoritmo que calcule e mostre a média 
// aritmética dos números lidos entre 13 e 73.

let media: number = 0;
let contador: number = 0;

for (let i:number = 13; i < 74; i++) {
    let array: [] =  
    console.log(i)
}
       